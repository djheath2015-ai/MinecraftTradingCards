package dev.djdoesstuff.tradingcards;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.util.RandomSource;

public class CardPackItem extends Item {
    public CardPackItem(Properties properties) { super(properties); }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) return InteractionResult.PASS;

        ItemStack pack = player.getItemInHand(hand);
        RandomSource random = level.getRandom();
        player.sendSystemMessage(Component.literal("You opened a Trading Card Pack!").withStyle(ChatFormatting.GOLD));

        for (int i = 0; i < 5; i++) {
            int roll = random.nextInt(100);
            String rarity;
            ChatFormatting colour;
            if (roll == 0) { rarity = "MYTHIC"; colour = ChatFormatting.LIGHT_PURPLE; }
            else if (roll < 5) { rarity = "LEGENDARY"; colour = ChatFormatting.GOLD; }
            else if (roll < 18) { rarity = "EPIC"; colour = ChatFormatting.DARK_PURPLE; }
            else if (roll < 43) { rarity = "RARE"; colour = ChatFormatting.BLUE; }
            else if (roll < 72) { rarity = "UNCOMMON"; colour = ChatFormatting.GREEN; }
            else { rarity = "COMMON"; colour = ChatFormatting.GRAY; }

            TradingCardsMod.Card card = TradingCardsMod.randomCard(random);
            ItemStack reward = TradingCardsMod.createCardStack(card, rarity, colour);
            if (!player.getInventory().add(reward)) player.drop(reward, false);
            player.sendSystemMessage(Component.literal("  " + rarity + " - " + card.name() + " (" + card.power() + " power)").withStyle(colour));
        }

        if (!player.getAbilities().instabuild) pack.shrink(1);
        return InteractionResult.SUCCESS;
    }
}
