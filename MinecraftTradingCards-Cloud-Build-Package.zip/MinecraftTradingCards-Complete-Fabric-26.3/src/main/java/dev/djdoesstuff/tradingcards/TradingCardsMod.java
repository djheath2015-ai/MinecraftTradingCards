package dev.djdoesstuff.tradingcards;

import com.mojang.brigadier.arguments.EntityArgument;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.itemgroup.v1.CreativeModeTabEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.component.DataComponents;
import net.minecraft.util.RandomSource;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class TradingCardsMod implements ModInitializer {
    public static final String MOD_ID = "tradingcards";

    public record Card(Item item, String name, int power) { }
    public static final List<Card> CARDS = new ArrayList<>();

    public static final Item CARD_PACK = register("card_pack", CardPackItem::new, new Item.Properties().stacksTo(16));
    public static final Item CARD_ALBUM = register("card_album", CardAlbumItem::new, new Item.Properties().stacksTo(1));

    public static final Card CREEPER = card("creeper_card", "Creeper", 5);
    public static final Card ZOMBIE = card("zombie_card", "Zombie", 4);
    public static final Card SKELETON = card("skeleton_card", "Skeleton", 4);
    public static final Card ENDERMAN = card("enderman_card", "Enderman", 7);
    public static final Card SPIDER = card("spider_card", "Spider", 3);
    public static final Card SLIME = card("slime_card", "Slime", 3);
    public static final Card WOLF = card("wolf_card", "Wolf", 4);
    public static final Card IRON_GOLEM = card("iron_golem_card", "Iron Golem", 8);
    public static final Card BLAZE = card("blaze_card", "Blaze", 6);
    public static final Card WARDEN = card("warden_card", "Warden", 10);
    public static final Card WITHER = card("wither_card", "Wither", 10);
    public static final Card ENDER_DRAGON = card("ender_dragon_card", "Ender Dragon", 12);

    private static Item register(String name, Function<Item.Properties, Item> factory, Item.Properties properties) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(MOD_ID, name));
        Item item = factory.apply(properties.setId(key));
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    private static Card card(String id, String name, int power) {
        Item item = register(id, Item::new, new Item.Properties().stacksTo(64));
        Card card = new Card(item, name, power);
        CARDS.add(card);
        return card;
    }

    @Override
    public void onInitialize() {
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS).register(entries -> {
            entries.accept(CARD_PACK);
            entries.accept(CARD_ALBUM);
            for (Card card : CARDS) entries.accept(card.item());
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(Commands.literal("cards")
                .executes(ctx -> showHelp(ctx.getSource()))
                .then(Commands.literal("help").executes(ctx -> showHelp(ctx.getSource())))
                .then(Commands.literal("album").executes(ctx -> showAlbum(ctx.getSource())))
                .then(Commands.literal("duel")
                    .then(Commands.argument("opponent", EntityArgument.player())
                        .executes(ctx -> duel(ctx.getSource(), EntityArgument.getPlayer(ctx, "opponent")))))
            )
        );
    }

    private static int showHelp(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal("=== MINECRAFT TRADING CARDS ===").withStyle(ChatFormatting.GOLD), false);
        source.sendSuccess(() -> Component.literal("Right-click a Card Pack to open 5 random cards."), false);
        source.sendSuccess(() -> Component.literal("/cards album - view cards in your inventory"), false);
        source.sendSuccess(() -> Component.literal("/cards duel <player> - compare your card deck power"), false);
        source.sendSuccess(() -> Component.literal("Trade by dropping a card for another player to pick up."), false);
        return 1;
    }

    private static int showAlbum(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        showAlbumFor(player);
        return 1;
    }

    public static void showAlbumFor(Player player) {
        Inventory inventory = player.getInventory();
        int total = 0;
        player.sendSystemMessage(Component.literal("=== YOUR CARD ALBUM ===").withStyle(ChatFormatting.LIGHT_PURPLE));
        for (Card card : CARDS) {
            int count = countCard(inventory, card.item());
            if (count > 0) {
                total += count;
                player.sendSystemMessage(Component.literal(card.name() + " x" + count + " | Base power: " + card.power()));
            }
        }
        player.sendSystemMessage(Component.literal("Total cards collected: " + total));
    }

    private static int countCard(Inventory inventory, Item item) {
        int count = 0;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (stack.is(item)) count += stack.getCount();
        }
        return count;
    }

    private static int deckPower(Inventory inventory) {
        int power = 0;
        for (Card card : CARDS) {
            for (int i = 0; i < inventory.getContainerSize(); i++) {
                ItemStack stack = inventory.getItem(i);
                if (stack.is(card.item())) {
                    String title = stack.get(DataComponents.CUSTOM_NAME) == null ? "COMMON" : stack.get(DataComponents.CUSTOM_NAME).getString();
                    int multiplier = title.startsWith("MYTHIC") ? 3 : title.startsWith("LEGENDARY") ? 2 : title.startsWith("EPIC") ? 2 : title.startsWith("RARE") ? 2 : title.startsWith("UNCOMMON") ? 1 : 1;
                    power += card.power() * multiplier * stack.getCount();
                }
            }
        }
        return power;
    }

    private static int duel(CommandSourceStack source, ServerPlayer opponent) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer challenger = source.getPlayerOrException();
        if (challenger.getUUID().equals(opponent.getUUID())) {
            source.sendFailure(Component.literal("You cannot duel yourself!"));
            return 0;
        }
        int yourPower = deckPower(challenger.getInventory());
        int theirPower = deckPower(opponent.getInventory());
        source.sendSuccess(() -> Component.literal("Your deck power: " + yourPower), false);
        source.sendSuccess(() -> Component.literal(opponent.getName().getString() + "'s deck power: " + theirPower), false);
        if (yourPower > theirPower) {
            source.sendSuccess(() -> Component.literal("You win the deck-power duel!" ).withStyle(ChatFormatting.GREEN), false);
            opponent.sendSystemMessage(Component.literal(challenger.getName().getString() + " won the card duel."));
        } else if (yourPower < theirPower) {
            source.sendSuccess(() -> Component.literal(opponent.getName().getString() + " wins this duel. Collect more powerful cards!" ).withStyle(ChatFormatting.RED), false);
            opponent.sendSystemMessage(Component.literal("You won the card duel against " + challenger.getName().getString() + "!"));
        } else {
            source.sendSuccess(() -> Component.literal("It's a draw! Your decks have equal power." ).withStyle(ChatFormatting.YELLOW), false);
            opponent.sendSystemMessage(Component.literal("Your card duel ended in a draw."));
        }
        return 1;
    }

    public static ItemStack createCardStack(Card card, String rarity, ChatFormatting colour) {
        ItemStack stack = new ItemStack(card.item());
        stack.set(DataComponents.CUSTOM_NAME, Component.literal(rarity + " " + card.name() + " Card").withStyle(colour));
        return stack;
    }

    public static Card randomCard(RandomSource random) {
        return CARDS.get(random.nextInt(CARDS.size()));
    }
}
