package dev.djdoesstuff.tradingcards;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public class CardAlbumItem extends Item {
    public CardAlbumItem(Properties properties) { super(properties); }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) return InteractionResult.PASS;
        TradingCardsMod.showAlbumFor(player);
        return InteractionResult.SUCCESS;
    }
}
